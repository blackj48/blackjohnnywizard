import xbmcgui

xbmcgui.Dialog().ok("Blackjohnny Wizard", "Το πρόσθετο εγκαταστάθηκε με επιτυχία!", "Περισσότερες λειτουργίες θα προστεθούν σύντομα.")
